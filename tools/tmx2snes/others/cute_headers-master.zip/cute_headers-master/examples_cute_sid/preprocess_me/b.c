SID( "hi" )
SID( "yoo" )
SID( "asdfjajsdfaiwjfkopasdkopkasopfkapsodfkpaosdfkaspodfkapsofdk" )
SID( "SID" )
