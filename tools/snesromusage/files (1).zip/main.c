/*
 * snesromusage - a "romusage"-style ROM/RAM usage report tool for
 * PVSnesLib projects, based on the .sym symbol file produced by
 * wla-dx's linker (wlalink).
 *
 * Inspired by https://github.com/bbbbbr/romusage (Game Boy / GBDK)
 * Adapted for the SNES memory map (LoROM / HiROM), as documented at
 * https://en.wikibooks.org/wiki/Super_NES_Programming/SNES_memory_map
 *
 * How it works
 * ------------
 * wlalink's .sym output (no$sns symbolic format) contains, among the
 * regular labels, a pair of synthetic labels around every linker
 * .SECTION / .RAMSECTION it placed:
 *
 *      0092fe48 SECTIONSTART_.AntNewtext_0x0
 *      0092fe48 AntNew
 *      ...
 *      0092fff0 SECTIONEND_.AntNewtext_0x0
 *
 * Every symbol address is written as an 8 hex digit number whose low
 * 24 bits are the flat SNES "long" address: bank = (addr>>16)&0xFF,
 * offset = addr & 0xFFFF (the top byte is always 0 in files produced
 * by wla-dx for the 65816).
 *
 * By pairing up every SECTIONSTART_x / SECTIONEND_x we recover the
 * exact byte range used by every section instance the linker placed,
 * which lets us reconstruct ROM/WRAM/SRAM usage per bank without
 * needing the original linkfile.
 *
 * Bank capacities (how many bytes a given bank can actually hold) are
 * derived from the well known LoROM / HiROM memory maps, mirrored
 * banks are folded onto their physical bank so they are not double
 * counted.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <stdint.h>
#include <errno.h>

/* ------------------------------------------------------------------ */
/* Config / constants                                                  */
/* ------------------------------------------------------------------ */

#define MAX_LABEL_LEN 512
#define BAR_WIDTH 28

typedef enum { MODE_LOROM, MODE_HIROM, MODE_EXHIROM } RomMode;

typedef enum { MEM_ROM, MEM_WRAM, MEM_SRAM, MEM_UNKNOWN } MemType;

static const char *memtype_name(MemType t) {
    switch (t) {
        case MEM_ROM:  return "ROM";
        case MEM_WRAM: return "WRAM";
        case MEM_SRAM: return "SRAM";
        default:       return "?";
    }
}

/* ------------------------------------------------------------------ */
/* Symbol table                                                        */
/* ------------------------------------------------------------------ */

typedef struct {
    uint32_t addr;              /* 24-bit flat SNES address */
    char     name[MAX_LABEL_LEN];
} Symbol;

static Symbol *g_symbols = NULL;
static size_t  g_symbol_count = 0;
static size_t  g_symbol_cap = 0;

static void symbol_push(uint32_t addr, const char *name) {
    if (g_symbol_count == g_symbol_cap) {
        g_symbol_cap = g_symbol_cap ? g_symbol_cap * 2 : 4096;
        g_symbols = realloc(g_symbols, g_symbol_cap * sizeof(Symbol));
        if (!g_symbols) { fprintf(stderr, "out of memory\n"); exit(1); }
    }
    g_symbols[g_symbol_count].addr = addr & 0xFFFFFFu;
    strncpy(g_symbols[g_symbol_count].name, name, MAX_LABEL_LEN - 1);
    g_symbols[g_symbol_count].name[MAX_LABEL_LEN - 1] = '\0';
    g_symbol_count++;
}

/* ------------------------------------------------------------------ */
/* Section instances (paired SECTIONSTART_/SECTIONEND_)                */
/* ------------------------------------------------------------------ */

typedef struct {
    char     key[MAX_LABEL_LEN]; /* name after the SECTIONSTART_/SECTIONEND_ prefix */
    uint32_t start_addr;
} OpenSection;

typedef struct {
    char     name[MAX_LABEL_LEN]; /* section name (without SECTIONSTART_/END_ prefix) */
    uint32_t start_addr;
    uint32_t end_addr;            /* exclusive */
    uint32_t size;
    MemType  type;
    int      bank;                /* physical bank this was folded onto, or raw bank for WRAM/unknown */
} Section;

static Section *g_sections = NULL;
static size_t   g_section_count = 0;
static size_t   g_section_cap = 0;

static void section_push(const char *name, uint32_t start, uint32_t end) {
    if (g_section_count == g_section_cap) {
        g_section_cap = g_section_cap ? g_section_cap * 2 : 1024;
        g_sections = realloc(g_sections, g_section_cap * sizeof(Section));
        if (!g_sections) { fprintf(stderr, "out of memory\n"); exit(1); }
    }
    Section *s = &g_sections[g_section_count++];
    strncpy(s->name, name, MAX_LABEL_LEN - 1);
    s->name[MAX_LABEL_LEN - 1] = '\0';
    s->start_addr = start;
    s->end_addr = end;
    s->size = (end >= start) ? (end - start) : 0;
    s->type = MEM_UNKNOWN;
    s->bank = -1;
}

static OpenSection *g_open = NULL;
static size_t g_open_count = 0;
static size_t g_open_cap = 0;

static void open_push(const char *key, uint32_t addr) {
    if (g_open_count == g_open_cap) {
        g_open_cap = g_open_cap ? g_open_cap * 2 : 256;
        g_open = realloc(g_open, g_open_cap * sizeof(OpenSection));
        if (!g_open) { fprintf(stderr, "out of memory\n"); exit(1); }
    }
    strncpy(g_open[g_open_count].key, key, MAX_LABEL_LEN - 1);
    g_open[g_open_count].key[MAX_LABEL_LEN - 1] = '\0';
    g_open[g_open_count].start_addr = addr;
    g_open_count++;
}

/* find most recent open section matching key (LIFO), remove it, return start addr.
 * returns 1 on success, 0 if not found. */
static int open_pop_matching(const char *key, uint32_t *out_start) {
    for (size_t i = g_open_count; i-- > 0; ) {
        if (strcmp(g_open[i].key, key) == 0) {
            *out_start = g_open[i].start_addr;
            /* remove by shifting down (keeps relative order of the rest, cheap enough) */
            memmove(&g_open[i], &g_open[i + 1], (g_open_count - i - 1) * sizeof(OpenSection));
            g_open_count--;
            return 1;
        }
    }
    return 0;
}

/* ------------------------------------------------------------------ */
/* .sym file parsing                                                   */
/* ------------------------------------------------------------------ */

static char *trim(char *s) {
    while (isspace((unsigned char)*s)) s++;
    if (*s == '\0') return s;
    char *end = s + strlen(s) - 1;
    while (end > s && isspace((unsigned char)*end)) *end-- = '\0';
    return s;
}

/* Parses one non-comment, non-empty line.
 * Supports:
 *   "AABBCC label"        (no$sns flat 24-bit hex, wla-dx default .sym)
 *   "AA:BBCC label"       (bank:offset hex, alternate wla-dx/emulator .sym style)
 * Returns 1 and fills *addr/name on success, 0 if the line isn't a symbol line. */
static int parse_symbol_line(char *line, uint32_t *addr, char *name_out) {
    char *s = trim(line);
    if (*s == '\0' || *s == ';' || *s == '[') return 0;

    char tok[64];
    int n = 0;
    while (s[n] && !isspace((unsigned char)s[n]) && n < (int)sizeof(tok) - 1) { tok[n] = s[n]; n++; }
    tok[n] = '\0';
    if (n == 0) return 0;
    while (s[n] && isspace((unsigned char)s[n])) n++;
    char *label = s + n;
    if (*label == '\0') return 0;

    /* strip any trailing comment / extra columns after the label */
    char *end = label;
    while (*end && !isspace((unsigned char)*end)) end++;
    *end = '\0';

    unsigned int bank = 0, off = 0, flat = 0;
    char *colon = strchr(tok, ':');
    if (colon) {
        *colon = '\0';
        if (sscanf(tok, "%x", &bank) != 1) return 0;
        if (sscanf(colon + 1, "%x", &off) != 1) return 0;
        *addr = ((bank & 0xFFu) << 16) | (off & 0xFFFFu);
    } else {
        /* must look like plain hex */
        for (char *p = tok; *p; p++) if (!isxdigit((unsigned char)*p)) return 0;
        if (sscanf(tok, "%x", &flat) != 1) return 0;
        *addr = flat & 0xFFFFFFu;
    }

    strncpy(name_out, label, MAX_LABEL_LEN - 1);
    name_out[MAX_LABEL_LEN - 1] = '\0';
    return 1;
}

static void load_sym_file(const char *path) {
    FILE *f = fopen(path, "r");
    if (!f) { fprintf(stderr, "error: cannot open '%s': %s\n", path, strerror(errno)); exit(1); }

    char line[2048];
    uint32_t addr;
    char name[MAX_LABEL_LEN];
    while (fgets(line, sizeof(line), f)) {
        if (parse_symbol_line(line, &addr, name)) {
            symbol_push(addr, name);
        }
    }
    fclose(f);
}

/* ------------------------------------------------------------------ */
/* Building sections out of SECTIONSTART_/SECTIONEND_ pairs            */
/* ------------------------------------------------------------------ */

#define PFX_START "SECTIONSTART_"
#define PFX_END   "SECTIONEND_"

static void build_sections(void) {
    for (size_t i = 0; i < g_symbol_count; i++) {
        const char *nm = g_symbols[i].name;
        if (strncmp(nm, PFX_START, strlen(PFX_START)) == 0) {
            open_push(nm + strlen(PFX_START), g_symbols[i].addr);
        } else if (strncmp(nm, PFX_END, strlen(PFX_END)) == 0) {
            uint32_t start;
            const char *key = nm + strlen(PFX_END);
            if (open_pop_matching(key, &start)) {
                section_push(key, start, g_symbols[i].addr);
            } else {
                fprintf(stderr, "warning: SECTIONEND_%s has no matching SECTIONSTART_ (ignored)\n", key);
            }
        }
    }
    if (g_open_count > 0) {
        for (size_t i = 0; i < g_open_count; i++)
            fprintf(stderr, "warning: SECTIONSTART_%s was never closed (ignored)\n", g_open[i].key);
    }
}

/* ------------------------------------------------------------------ */
/* SNES memory map classification                                      */
/* ------------------------------------------------------------------ */

/* Classifies one section by its start address (a section never crosses
 * a bank boundary in practice for wla-dx/pvsneslib output; if it did,
 * we still charge the whole size to the bank it starts in). */
static void classify_section(Section *s, RomMode mode) {
    unsigned bank = (s->start_addr >> 16) & 0xFF;
    unsigned off  = s->start_addr & 0xFFFF;

    if (bank == 0x7E || bank == 0x7F) {
        s->type = MEM_WRAM;
        s->bank = (int)bank;
        return;
    }

    /* $0000-$1FFF of every "system" bank ($00-$3F/$80-$BF, and also
     * $40-$7D/$C0-$FF under HiROM) is hard-wired to shadow the first two
     * pages of WRAM (bank $7E). This is true in BOTH LoROM and HiROM, and
     * pvsneslib/wla-dx routinely places direct-page variables there, so
     * fold it onto the real WRAM bank $7E instead of flagging it unknown. */
    int is_system_bank = (bank <= 0x3F) || (bank >= 0x80 && bank <= 0xBF);
    if (is_system_bank && off < 0x2000) {
        s->type = MEM_WRAM;
        s->bank = 0x7E;
        return;
    }

    if (mode == MODE_LOROM) {
        if (bank == 0xFE || bank == 0xFF) {
            s->type = (off < 0x8000) ? MEM_SRAM : MEM_ROM;
            s->bank = (int)bank;
            return;
        }
        unsigned pb = (bank >= 0x80 && bank <= 0xFD) ? (bank - 0x80) : bank;
        if (pb <= 0x7D) {
            if (pb >= 0x70 && pb <= 0x7D) {
                s->type = (off < 0x8000) ? MEM_SRAM : MEM_ROM;
                s->bank = (int)pb;
                return;
            }
            if (pb <= 0x3F) {
                if (off < 0x8000) { s->type = MEM_UNKNOWN; s->bank = (int)pb; return; } /* $2000-$7FFF: hw regs, no user data expected here */
                s->type = MEM_ROM; s->bank = (int)pb; return;
            }
            /* 0x40 - 0x6F : whole bank is ROM (assuming no MAD-1 chip) */
            s->type = MEM_ROM; s->bank = (int)pb; return;
        }
        s->type = MEM_UNKNOWN; s->bank = (int)bank; return;
    } else {
        /* HiROM / ExHiROM (ExHiROM handled as a HiROM approximation) */
        if (bank >= 0x40 && bank <= 0x7D) { s->type = MEM_ROM; s->bank = (int)(bank - 0x40); return; }
        if (bank >= 0xC0) { s->type = MEM_ROM; s->bank = (int)(bank - 0xC0); return; }
        /* bank in 0x00-0x3F or 0x80-0xBF : mirrors */
        unsigned pb = bank & 0x3F;
        int is_sram_capable_bank = ((bank >= 0x20 && bank <= 0x3F) || (bank >= 0xA0 && bank <= 0xBF));
        if (off >= 0x8000) { s->type = MEM_ROM; s->bank = (int)pb; return; }
        if (is_sram_capable_bank && off >= 0x6000 && off < 0x8000) { s->type = MEM_SRAM; s->bank = (int)pb; return; }
        s->type = MEM_UNKNOWN; s->bank = (int)pb; return;
    }
}

static uint32_t rom_bank_capacity(RomMode mode, int pb) {
    if (mode == MODE_LOROM) {
        if (pb == 0xFE || pb == 0xFF) return 0x8000;
        if (pb >= 0x70 && pb <= 0x7D) return 0x8000;
        if (pb >= 0x40 && pb <= 0x6F) return 0x10000;
        if (pb <= 0x3F) return 0x8000;
        return 0;
    } else {
        if (pb <= 0x3F) return 0x10000;
        return 0;
    }
}

/* ------------------------------------------------------------------ */
/* Reporting                                                            */
/* ------------------------------------------------------------------ */

typedef struct {
    char     label[40];
    char     type[8];
    uint32_t range_lo, range_hi; /* inclusive, informational only */
    uint32_t size;
    uint32_t used;
} ReportRow;

static ReportRow *g_rows = NULL;
static size_t g_row_count = 0, g_row_cap = 0;

static void row_push(const char *label, const char *type, uint32_t lo, uint32_t hi, uint32_t size, uint32_t used) {
    if (g_row_count == g_row_cap) {
        g_row_cap = g_row_cap ? g_row_cap * 2 : 32;
        g_rows = realloc(g_rows, g_row_cap * sizeof(ReportRow));
    }
    ReportRow *r = &g_rows[g_row_count++];
    snprintf(r->label, sizeof(r->label), "%s", label);
    snprintf(r->type, sizeof(r->type), "%s", type);
    r->range_lo = lo; r->range_hi = hi; r->size = size; r->used = used;
}

static void print_bar(uint32_t used, uint32_t size) {
    int filled = 0;
    if (size > 0) filled = (int)((uint64_t)used * BAR_WIDTH / size);
    if (filled > BAR_WIDTH) filled = BAR_WIDTH;
    putchar('|');
    for (int i = 0; i < BAR_WIDTH; i++) putchar(i < filled ? '#' : '.');
    putchar('|');
}

static void print_row(const ReportRow *r) {
    uint32_t free_b = (r->size >= r->used) ? (r->size - r->used) : 0;
    double used_pct = r->size ? (100.0 * r->used / r->size) : 0.0;
    double free_pct = r->size ? (100.0 * free_b / r->size) : 0.0;
    char range[24];
    snprintf(range, sizeof(range), "0x%04X-0x%04X", r->range_lo, r->range_hi);
    printf("%-14s %-6s %-13s %7u %7u %5.0f%% %7u %5.0f%%  ", r->label, r->type, range,
           r->size, r->used, used_pct, free_b, free_pct);
    print_bar(r->used, r->size);
    putchar('\n');
}

static void print_csv_row(const ReportRow *r) {
    uint32_t free_b = (r->size >= r->used) ? (r->size - r->used) : 0;
    double used_pct = r->size ? (100.0 * r->used / r->size) : 0.0;
    double free_pct = r->size ? (100.0 * free_b / r->size) : 0.0;
    printf("%s,%s,0x%04X,0x%04X,%u,%u,%.2f,%u,%.2f\n",
           r->label, r->type, r->range_lo, r->range_hi, r->size, r->used, used_pct, free_b, free_pct);
}

/* ------------------------------------------------------------------ */
/* main                                                                 */
/* ------------------------------------------------------------------ */

static void usage(const char *prog, FILE *out) {
    fprintf(out,
        "snesromusage - ROM/RAM usage report for PVSnesLib projects (from wla-dx .sym files)\n\n"
        "usage: %s [options] file.sym\n\n"
        "options:\n"
        "  --lorom              force LoROM memory map (default: auto-detect)\n"
        "  --hirom              force HiROM memory map\n"
        "  --exhirom            force ExHiROM memory map (approximate, treated as HiROM)\n"
        "  --rombanks=N         also list completely unused ROM banks up to bank N-1\n"
        "  --sram=KB            declared cartridge SRAM size in KB (default: 0 = auto)\n"
        "  --top=N              show the N largest sections (default: 15, 0 disables)\n"
        "  --sections           dump every parsed section (bank/type/range/size)\n"
        "  --csv                machine readable CSV output instead of the table\n"
        "  --no-color           (kept for compatibility, output has no color codes)\n"
        "  -h, --help           show this help\n", prog);
}

typedef struct { Section *s; } SortRef;
static int cmp_section_size_desc(const void *a, const void *b) {
    const Section *sa = *(Section * const *)a;
    const Section *sb = *(Section * const *)b;
    if (sb->size != sa->size) return (sb->size > sa->size) ? 1 : -1;
    return 0;
}

int main(int argc, char **argv) {
    const char *sym_path = NULL;
    RomMode mode = MODE_LOROM;
    int mode_forced = 0;
    long rombanks_arg = -1;
    long sram_kb_arg = -1;
    int top_n = 15;
    int show_sections = 0;
    int csv = 0;

    for (int i = 1; i < argc; i++) {
        char *a = argv[i];
        if (!strcmp(a, "-h") || !strcmp(a, "--help")) { usage(argv[0], stdout); return 0; }
        else if (!strcmp(a, "--lorom")) { mode = MODE_LOROM; mode_forced = 1; }
        else if (!strcmp(a, "--hirom")) { mode = MODE_HIROM; mode_forced = 1; }
        else if (!strcmp(a, "--exhirom")) { mode = MODE_EXHIROM; mode_forced = 1; }
        else if (!strncmp(a, "--rombanks=", 11)) { rombanks_arg = strtol(a + 11, NULL, 0); }
        else if (!strncmp(a, "--sram=", 7)) { sram_kb_arg = strtol(a + 7, NULL, 0); }
        else if (!strncmp(a, "--top=", 6)) { top_n = (int)strtol(a + 6, NULL, 0); }
        else if (!strcmp(a, "--sections")) { show_sections = 1; }
        else if (!strcmp(a, "--csv")) { csv = 1; }
        else if (!strcmp(a, "--no-color")) { /* no-op */ }
        else if (a[0] == '-') { fprintf(stderr, "unknown option: %s\n", a); usage(argv[0], stderr); return 1; }
        else { sym_path = a; }
    }

    if (!sym_path) { usage(argv[0], stderr); return 1; }

    load_sym_file(sym_path);
    if (g_symbol_count == 0) {
        fprintf(stderr, "error: no symbols parsed from '%s' - is this a wla-dx .sym file?\n", sym_path);
        return 1;
    }
    build_sections();
    if (g_section_count == 0) {
        fprintf(stderr, "error: no SECTIONSTART_/SECTIONEND_ pairs found - this doesn't look like a "
                         "wlalink-generated .sym file (need symbol export enabled, e.g. wlalink -S).\n");
        return 1;
    }

    /* auto-detect LoROM vs HiROM. $0000-$1FFF of a system bank is always a
     * WRAM mirror in both modes, so it proves nothing either way. But a
     * non-WRAM section sitting in $2000-$7FFF of a system bank can only
     * happen under HiROM (that range has no ROM mapping at all in LoROM). */
    if (!mode_forced) {
        int hirom_guess = 0;
        for (size_t i = 0; i < g_section_count; i++) {
            unsigned bank = (g_sections[i].start_addr >> 16) & 0xFF;
            unsigned off  = g_sections[i].start_addr & 0xFFFF;
            if (bank == 0x7E || bank == 0x7F) continue;
            int in_mirror_range = (bank <= 0x3F) || (bank >= 0x80 && bank <= 0xBF);
            if (in_mirror_range && off >= 0x2000 && off < 0x8000) { hirom_guess = 1; break; }
        }
        mode = hirom_guess ? MODE_HIROM : MODE_LOROM;
    }

    for (size_t i = 0; i < g_section_count; i++) classify_section(&g_sections[i], mode);

    if (show_sections) {
        printf("%-34s %-6s %-8s %8s\n", "Section", "Type", "Bank", "Size");
        for (size_t i = 0; i < g_section_count; i++) {
            Section *s = &g_sections[i];
            printf("%-34s %-6s $%02X      %8u\n", s->name, memtype_name(s->type),
                   s->bank >= 0 ? s->bank : (int)((s->start_addr >> 16) & 0xFF), s->size);
        }
        printf("\n");
    }

    /* aggregate ROM usage per physical bank, WRAM per bank (7E/7F), SRAM as one pool */
    uint32_t rom_used[256]; memset(rom_used, 0, sizeof(rom_used));
    int rom_bank_seen[256]; memset(rom_bank_seen, 0, sizeof(rom_bank_seen));
    uint32_t wram_used_7e = 0, wram_used_7f = 0;
    uint32_t sram_used_total = 0;
    uint32_t unknown_used_total = 0;

    for (size_t i = 0; i < g_section_count; i++) {
        Section *s = &g_sections[i];
        switch (s->type) {
            case MEM_ROM:
                if (s->bank >= 0 && s->bank < 256) { rom_used[s->bank] += s->size; rom_bank_seen[s->bank] = 1; }
                break;
            case MEM_WRAM:
                if (s->bank == 0x7E) wram_used_7e += s->size;
                else if (s->bank == 0x7F) wram_used_7f += s->size;
                break;
            case MEM_SRAM:
                sram_used_total += s->size;
                break;
            default:
                unknown_used_total += s->size;
                break;
        }
    }

    int max_bank = -1;
    for (int b = 0; b < 256; b++) if (rom_bank_seen[b]) max_bank = b;
    if (rombanks_arg > 0 && rombanks_arg - 1 > max_bank) max_bank = (int)rombanks_arg - 1;

    /* build report rows: ROM banks */
    for (int b = 0; b <= max_bank; b++) {
        uint32_t cap = rom_bank_capacity(mode, b);
        if (cap == 0) continue; /* not a valid ROM bank in this mode (e.g. 0x7E/0x7F skipped already) */
        if (!rom_bank_seen[b] && rombanks_arg <= 0) continue; /* skip unused banks unless explicitly requested */
        char label[40];
        snprintf(label, sizeof(label), "ROM bank $%02X", b);
        uint32_t lo = (mode == MODE_LOROM && b >= 0x40 && b <= 0x6F) ? 0x0000 :
                      (mode == MODE_HIROM) ? 0x0000 : 0x8000;
        uint32_t hi = 0xFFFF;
        row_push(label, "ROM", lo, hi, cap, rom_used[b]);
    }
    /* FE/FF LoROM ROM extension banks, only if used */
    if (mode == MODE_LOROM) {
        if (rom_bank_seen[0xFE]) row_push("ROM bank $FE", "ROM", 0x8000, 0xFFFF, rom_bank_capacity(mode, 0xFE), rom_used[0xFE]);
        if (rom_bank_seen[0xFF]) row_push("ROM bank $FF", "ROM", 0x8000, 0xFFFF, rom_bank_capacity(mode, 0xFF), rom_used[0xFF]);
    }

    /* WRAM: fixed hardware fact, independent of mapping mode */
    row_push("WRAM bank $7E", "WRAM", 0x0000, 0xFFFF, 0x10000, wram_used_7e);
    row_push("WRAM bank $7F", "WRAM", 0x0000, 0xFFFF, 0x10000, wram_used_7f);

    /* SRAM: single aggregated pool sized from --sram, or auto-sized to the
     * next convenient size that fits what's actually used */
    if (sram_kb_arg > 0 || sram_used_total > 0) {
        uint32_t cap;
        if (sram_kb_arg > 0) {
            cap = (uint32_t)sram_kb_arg * 1024u;
        } else {
            cap = 2048; /* SNES header SRAM sizes are typically 2/8/32/... KB; start at 2KB */
            while (cap < sram_used_total) cap *= 2;
        }
        row_push("Cartridge SRAM", "SRAM", 0x0000, cap ? cap - 1 : 0, cap, sram_used_total);
    }

    /* ---------------- output ---------------- */
    if (csv) {
        printf("Label,Type,RangeLo,RangeHi,Size,Used,Used%%,Free,Free%%\n");
        for (size_t i = 0; i < g_row_count; i++) print_csv_row(&g_rows[i]);
    } else {
        printf("wla-dx symbol file : %s\n", sym_path);
        printf("Memory map          : %s%s\n",
               mode == MODE_LOROM ? "LoROM" : mode == MODE_HIROM ? "HiROM" : "ExHiROM (approx.)",
               mode_forced ? "" : "  (auto-detected)");
        printf("Sections parsed      : %zu\n\n", g_section_count);

        printf("%-14s %-6s %-13s %7s %7s %6s %7s %6s\n",
               "Bank", "Type", "Range", "Size", "Used", "Used%", "Free", "Free%");
        printf("-------------- ------ ------------- ------- ------- ------ ------- ------\n");

        uint32_t tot_rom_size = 0, tot_rom_used = 0;
        uint32_t tot_wram_size = 0, tot_wram_used = 0;
        uint32_t tot_sram_size = 0, tot_sram_used = 0;

        for (size_t i = 0; i < g_row_count; i++) {
            print_row(&g_rows[i]);
            if (!strcmp(g_rows[i].type, "ROM"))  { tot_rom_size += g_rows[i].size; tot_rom_used += g_rows[i].used; }
            if (!strcmp(g_rows[i].type, "WRAM")) { tot_wram_size += g_rows[i].size; tot_wram_used += g_rows[i].used; }
            if (!strcmp(g_rows[i].type, "SRAM")) { tot_sram_size += g_rows[i].size; tot_sram_used += g_rows[i].used; }
        }

        printf("-------------- ------ ------------- ------- ------- ------ ------- ------\n");
        ReportRow tot;
        if (tot_rom_size) {
            row_push("TOTAL ROM", "ROM", 0, 0, tot_rom_size, tot_rom_used);
            print_row(&g_rows[g_row_count - 1]);
        }
        if (tot_wram_size) {
            row_push("TOTAL WRAM", "WRAM", 0, 0, tot_wram_size, tot_wram_used);
            print_row(&g_rows[g_row_count - 1]);
        }
        if (tot_sram_size) {
            row_push("TOTAL SRAM", "SRAM", 0, 0, tot_sram_size, tot_sram_used);
            print_row(&g_rows[g_row_count - 1]);
        }
        (void)tot;

        if (unknown_used_total > 0) {
            printf("\nnote: %u bytes were placed in addresses this tool doesn't classify\n"
                     "      as ROM/WRAM/SRAM for %s (hardware register / mirrored area).\n"
                     "      Run with --sections to see exactly which sections these are.\n",
                   unknown_used_total, mode == MODE_LOROM ? "LoROM" : "HiROM");
        }

        if (top_n > 0) {
            Section **ptrs = malloc(g_section_count * sizeof(Section *));
            for (size_t i = 0; i < g_section_count; i++) ptrs[i] = &g_sections[i];
            qsort(ptrs, g_section_count, sizeof(Section *), cmp_section_size_desc);
            int n = top_n < (int)g_section_count ? top_n : (int)g_section_count;
            printf("\nTop %d largest sections:\n", n);
            printf("%-34s %-6s %-8s %8s\n", "Section", "Type", "Bank", "Size");
            for (int i = 0; i < n; i++) {
                Section *s = ptrs[i];
                printf("%-34s %-6s $%02X      %8u\n", s->name, memtype_name(s->type),
                       s->bank >= 0 ? s->bank : (int)((s->start_addr >> 16) & 0xFF), s->size);
            }
            free(ptrs);
        }
    }

    return 0;
}
