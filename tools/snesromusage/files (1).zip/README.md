# snesromusage

A [romusage](https://github.com/bbbbbr/romusage)-style ROM/RAM usage report
tool for [PVSnesLib](https://github.com/alekmaul/pvsneslib) projects, built
on top of the `.sym` symbol file produced by wla-dx's linker (`wlalink`).

It prints a per-bank breakdown of ROM, WRAM and SRAM usage, with a memory
**Type** column (ROM / WRAM / SRAM), free space, and a usage bar — no
linker script parsing, ROM binary, or map file required, just the `.sym`.

```
$ snesromusage chipschallenge.sym
wla-dx symbol file : chipschallenge.sym
Memory map          : LoROM  (auto-detected)
Sections parsed      : 204

Bank           Type   Range            Size    Used  Used%    Free  Free%
-------------- ------ ------------- ------- ------- ------ ------- ------
ROM bank $00   ROM    0x8000-0xFFFF   32768   32696   100%      72     0%  |###########################.|
ROM bank $01   ROM    0x8000-0xFFFF   32768   32762   100%       6     0%  |###########################.|
...
ROM bank $14   ROM    0x8000-0xFFFF   32768    8836    27%   23932    73%  |#######.....................|
WRAM bank $7E  WRAM   0x0000-0xFFFF   65536   35787    55%   29749    45%  |###############.............|
WRAM bank $7F  WRAM   0x0000-0xFFFF   65536    4188     6%   61348    94%  |#...........................|
-------------- ------ ------------- ------- ------- ------ ------- ------
TOTAL ROM      ROM    0x0000-0x0000  688128  664074    97%   24054     3%  |###########################.|
TOTAL WRAM     WRAM   0x0000-0x0000  131072   39975    30%   91097    70%  |########....................|

Top 15 largest sections:
Section                            Type   Bank         Size
SOUNDBANK0                         ROM    $05         32768
...
```

## Building

```
make
```

Requires nothing beyond a C99 compiler and libc — no external dependencies.
Produces a single `snesromusage` binary. `make install` copies it to
`/usr/local/bin` (override with `PREFIX=`).

## Usage

```
snesromusage [options] file.sym

  --lorom              force LoROM memory map (default: auto-detect)
  --hirom               force HiROM memory map
  --exhirom              force ExHiROM memory map (approximate, treated as HiROM)
  --rombanks=N          also list completely unused ROM banks up to bank N-1
  --sram=KB              declared cartridge SRAM size in KB (default: 0 = auto)
  --top=N                show the N largest sections (default: 15, 0 disables)
  --sections              dump every parsed section (bank/type/range/size)
  --csv                   machine readable CSV output instead of the table
  -h, --help              show this help
```

Generate the `.sym` file with wlalink's symbol export flag, e.g. in a
PVSnesLib `Makefile`/`snes_rules` build this is usually already produced
next to the `.sfc` ROM (wlalink `-S` / no$sns symbol export). Then run:

```
snesromusage myrom.sym
```

Add `--rombanks=N` if you want to see banks the linker hasn't touched yet
at all (e.g. to answer "how many banks do I have left to grow into" for a
project compiled with `N` ROM banks declared in its linkfile) — without it,
only banks that actually contain something are listed.

If your cartridge has SRAM, pass `--sram=<kilobytes>` (matching the
`SRAMSIZE` you declared in `hdr.asm`) to get an accurate SRAM capacity row;
otherwise the tool only shows a SRAM row (auto-sized) if it detects any
`.RAMSECTION` actually placed in the SRAM banks.

## How it works

wlalink's `.sym` output (no$sns symbolic format) wraps every linked
`.SECTION`/`.RAMSECTION` instance with a pair of synthetic labels:

```
0092fe48 SECTIONSTART_.AntNewtext_0x0
0092fe48 AntNew
...
0092fff0 SECTIONEND_.AntNewtext_0x0
```

Every symbol address is an 8 hex digit number whose low 24 bits are the
flat SNES "long" address (`bank = (addr>>16)&0xFF`, `offset = addr&0xFFFF`).
`snesromusage` pairs up every `SECTIONSTART_x`/`SECTIONEND_x` to recover
the exact byte range the linker placed for that section, then classifies
each range as ROM, WRAM or SRAM using the documented LoROM/HiROM memory
maps (see [SNES Programming/SNES memory
map](https://en.wikibooks.org/wiki/Super_NES_Programming/SNES_memory_map)),
folding mirrored banks (e.g. FastROM's `$80-$FF` LoROM mirror of `$00-$7D`,
or HiROM's `$C0-$FD`/`$80-$BF`/`$A0-$BF` mirrors) onto their physical bank
so nothing is double counted. Bank capacities (32KB vs 64KB per bank, which
banks carry SRAM, etc.) come from that same memory map rather than the
linkfile, so no linkfile/`hdr.asm` is required — only the `.sym`.

Also supports the alternate `bank:offset label` wla-dx symbol style used by
some emulator debuggers, in case your toolchain emits that format instead.

## Limitations

* ExHiROM is treated as a HiROM approximation (good enough to see gross
  usage, but bank folding for the extended address range isn't modeled).
* A section that spans more than one bank is charged entirely to the bank
  it starts in (this matches how PVSnesLib/wla-dx actually places sections
  in practice — they don't straddle bank boundaries).
* SRAM is reported as a single aggregated pool rather than per-bank, since
  the SNES mirrors a comparatively small physical SRAM chip repeatedly
  across many bank windows; per-bank capacity there isn't a meaningful
  number without knowing the physical chip size (`--sram`).
