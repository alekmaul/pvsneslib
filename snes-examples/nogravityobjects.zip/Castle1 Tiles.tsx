<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Castle1 Tiles" tilewidth="8" tileheight="8" tilecount="480" columns="24">
 <image source="castle1_tiles.png" trans="ff00ff" width="192" height="160"/>
</tileset>
